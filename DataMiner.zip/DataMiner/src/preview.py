import sys
import time
from typing import Dict
from datetime import datetime
import threading
from rich.console import Console
from rich.live import Live
from rich.table import Table
from rich.panel import Panel
from rich.layout import Layout
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn
from config.config import PREVIEW_SETTINGS

class LivePreview:
    def __init__(self, settings: dict = PREVIEW_SETTINGS):
        self.console = Console()
        self.settings = settings
        self.stats = {
            'total_processed': 0,
            'successful_extractions': 0,
            'failed_extractions': 0,
            'start_time': datetime.now(),
            'current_query': '',
            'latest_results': [],
            'api_calls': 0,
            'remaining_quota': 100
        }
        self.lock = threading.Lock()

    def update_stats(self, **kwargs):
        """Update scraping statistics"""
        with self.lock:
            for key, value in kwargs.items():
                if key in self.stats:
                    self.stats[key] = value

    def add_result(self, result: dict):
        """Add a new result to the preview"""
        with self.lock:
            self.stats['latest_results'].insert(0, result)
            self.stats['latest_results'] = self.stats['latest_results'][:self.settings['max_results_shown']]
            self.stats['successful_extractions'] += 1
            self.stats['total_processed'] += 1

    def create_stats_table(self) -> Table:
        """Create statistics table"""
        table = Table(title="Scraping Statistics", border_style="blue")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")

        elapsed_time = datetime.now() - self.stats['start_time']
        
        stats = [
            ("Total Processed", str(self.stats['total_processed'])),
            ("Successful Extractions", str(self.stats['successful_extractions'])),
            ("Failed Extractions", str(self.stats['failed_extractions'])),
            ("API Calls", str(self.stats['api_calls'])),
            ("Remaining Quota", f"{self.stats['remaining_quota']}%"),
            ("Running Time", str(elapsed_time).split('.')[0]),
            ("Current Query", self.stats['current_query'])
        ]
        
        for metric, value in stats:
            table.add_row(metric, value)

        return table

    def create_results_table(self) -> Table:
        """Create results preview table"""
        table = Table(title="Latest Results", border_style="blue")
        table.add_column("Name", style="cyan", width=20)
        table.add_column("Position", style="green", width=20)
        table.add_column("Company", style="yellow", width=30)
        table.add_column("Contact", style="magenta", width=30)

        for result in self.stats['latest_results']:
            contact_info = f"📧 {result.get('email', 'N/A')}\n📱 {result.get('phone', 'N/A')}"
            table.add_row(
                result.get('name', 'N/A'),
                result.get('position', 'N/A'),
                result.get('company', 'N/A'),
                contact_info
            )

        return table

    def create_layout(self) -> Layout:
        """Create the main layout"""
        layout = Layout()
        layout.split_column(
            Layout(Panel(self.create_stats_table(), title="Statistics"), size=10),
            Layout(Panel(self.create_results_table(), title="Live Preview"), size=15)
        )
        return layout

    def start_preview(self):
        """Start the live preview"""
        try:
            with Live(self.create_layout(), refresh_per_second=1/self.settings['refresh_rate']) as live:
                while True:
                    live.update(self.create_layout())
                    time.sleep(self.settings['refresh_rate'])
        except Exception as e:
            logging.error(f"Error in live preview: {str(e)}")