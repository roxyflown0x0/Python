import requests
import time
import random
import pandas as pd
from typing import List, Dict, Any, Optional
import logging
from datetime import datetime
from tqdm import tqdm
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

from src.extractor import ContactExtractor
from src.preview import LivePreview
from src.utils import save_json, format_filename
from config.config import SCRAPER_SETTINGS, RATE_LIMIT

class ManufacturingContactScraper:
    def __init__(self, api_keys: list[str], cse_ids: list[str], preview_settings: dict):
        self.api_keys = api_keys
        self.cse_ids = cse_ids
        self.current_key_index = 0
        self.current_cse_index = 0
        self.results = []
        self.extractor = ContactExtractor()
        self.preview = LivePreview(preview_settings)
        self.preview_thread = None
        self.session = requests.Session()
        self.session.headers.update({'User-Agent': SCRAPER_SETTINGS['user_agent']})
        self.rate_limits = {key: {'calls': 0, 'last_reset': datetime.now()} for key in api_keys}

    def rotate_credentials(self):
        """Rotate API keys and CSE IDs to avoid quota limits"""
        self.current_key_index = (self.current_key_index + 1) % len(self.api_keys)
        self.current_cse_index = (self.current_cse_index + 1) % len(self.cse_ids)
        logging.info("Rotated to new API credentials")

    def check_rate_limit(self) -> bool:
        """Check if current API key has exceeded rate limits"""
        current_key = self.api_keys[self.current_key_index]
        now = datetime.now()
        
        # Reset daily counter if needed
        if (now - self.rate_limits[current_key]['last_reset']).days > 0:
            self.rate_limits[current_key] = {'calls': 0, 'last_reset': now}
        
        # Check if exceeded daily limit
        if self.rate_limits[current_key]['calls'] >= RATE_LIMIT['max_requests_per_day']:
            return False
        
        return True

    def search(self, query: str, start_index: int = 1) -> Optional[Dict[str, Any]]:
        """Perform a Google Custom Search"""
        if not self.check_rate_limit():
            self.rotate_credentials()
            return self.search(query, start_index)
        
        base_url = "https://www.googleapis.com/customsearch/v1"
        
        params = {
            'key': self.api_keys[self.current_key_index],
            'cx': self.cse_ids[self.current_cse_index],
            'q': query,
            'start': start_index,
            'num': SCRAPER_SETTINGS['batch_size']
        }
        
        try:
            response = self.session.get(
                base_url, 
                params=params,
                timeout=SCRAPER_SETTINGS['timeout'],
                verify=SCRAPER_SETTINGS['verify_ssl']
            )
            
            # Update rate limit counter
            current_key = self.api_keys[self.current_key_index]
            self.rate_limits[current_key]['calls'] += 1
            
            if response.status_code == 429:  # Quota exceeded
                logging.warning("API quota exceeded, rotating credentials")
                self.rotate_credentials()
                return self.search(query, start_index)
            
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as e:
            logging.error(f"Error during search: {str(e)}")
            return None

    def start_preview(self):
        """Start the live preview in a separate thread"""
        self.preview_thread = threading.Thread(target=self.preview.start_preview)
        self.preview_thread.daemon = True
        self.preview_thread.start()

    def process_search_result(self, item: Dict[str, Any], query: str) -> Optional[Dict[str, Any]]:
        """Process a single search result"""
        try:
            title = item.get('title', '')
            snippet = item.get('snippet', '')
            link = item.get('link', '')
            
            # Combine title and snippet for better extraction
            full_text = f"{title}\n{snippet}"
            
            # Extract contact information
            contact_info = self.extractor.extract_contact_info(full_text, link, query)
            
            if any(contact_info.values()):
                self.preview.add_result(contact_info)
                return contact_info
                
        except Exception as e:
            logging.error(f"Error processing search result: {str(e)}")
            self.preview.update_stats(failed_extractions=
                self.preview.stats['failed_extractions'] + 1)
        
        return None

    def scrape_manufacturing_contacts(self, custom_dorks: list[str]):
        """Main scraping function with custom dorks"""
        # Start the live preview
        self.start_preview()
        
        with ThreadPoolExecutor(max_workers=SCRAPER_SETTINGS.get('max_workers', 5)) as executor:
            futures = []
            
            for dork in custom_dorks:
                self.preview.update_stats(current_query=dork)
                logging.info(f"Searching with dork: {dork}")
                
                start_index = 1
                while start_index < SCRAPER_SETTINGS['max_results_per_query']:
                    try:
                        search_result = self.search(dork, start_index)
                        
                        if not search_result or 'items' not in search_result:
                            break
                        
                        # Submit each result for processing
                        for item in search_result['items']:
                            futures.append(
                                executor.submit(self.process_search_result, item, dork)
                            )
                        
                        # Update preview stats
                        self.preview.update_stats(
                            api_calls=self.preview.stats['api_calls'] + 1,
                            remaining_quota=100 - (self.preview.stats['api_calls'] * 100 // RATE_LIMIT['max_requests_per_day'])
                        )
                        
                        start_index += SCRAPER_SETTINGS['batch_size']
                        time.sleep(random.uniform(
                            SCRAPER_SETTINGS['delay_min'],
                            SCRAPER_SETTINGS['delay_max']
                        ))
                        
                    except Exception as e:
                        logging.error(f"Error processing dork '{dork}': {str(e)}")
                        break
            
            # Collect results
            for future in as_completed(futures):
                result = future.result()
                if result:
                    self.results.append(result)

    def save_results(self, filename_prefix: str = 'manufacturing_contacts'):
        """Save results to multiple formats"""
        if not self.results:
            logging.warning("No results to save")
            return
        
        # Save to CSV
        csv_filename = format_filename(filename_prefix, 'csv')
        df = pd.DataFrame(self.results)
        df.to_csv(f'output/{csv_filename}', index=False)
        logging.info(f"Results saved to CSV: {csv_filename}")
        
        # Save to JSON
        json_filename = format_filename(filename_prefix, 'json')
        save_json(self.results, json_filename)
        
        # Save to Excel
        excel_filename = format_filename(filename_prefix, 'xlsx')
        df.to_excel(f'output/{excel_filename}', index=False)
        logging.info(f"Results saved to Excel: {excel_filename}")