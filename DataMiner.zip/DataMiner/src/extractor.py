import re
from typing import Dict, Optional
from config.config import PATTERNS
from src.utils import clean_text
import logging

class ContactExtractor:
    def __init__(self):
        self.patterns = PATTERNS

    def extract_contact_info(self, text: str, url: str, source_query: str) -> dict:
        """Extract contact information from text"""
        text = clean_text(text)
        
        contact_info = {
            'name': '',
            'position': '',
            'company': '',
            'phone': '',
            'email': '',
            'address': '',
            'source_url': url,
            'source_query': source_query,
            'extraction_timestamp': datetime.now().isoformat()
        }
        
        try:
            # Extract information using patterns
            for field, pattern in self.patterns.items():
                matches = re.findall(pattern, text)
                if matches:
                    contact_info[field] = clean_text(matches[0])
            
            return self.validate_contact_info(contact_info)
            
        except Exception as e:
            logging.error(f"Error extracting contact info: {str(e)}")
            return contact_info

    def validate_contact_info(self, contact_info: dict) -> dict:
        """Validate and clean extracted contact information"""
        cleaned = contact_info.copy()
        
        # Clean phone numbers
        if cleaned['phone']:
            cleaned['phone'] = self.standardize_phone(cleaned['phone'])
        
        # Clean email addresses
        if cleaned['email']:
            cleaned['email'] = cleaned['email'].lower().strip()
            
        # Validate email format
        if cleaned['email'] and not self.is_valid_email(cleaned['email']):
            cleaned['email'] = ''
            
        return cleaned

    def standardize_phone(self, phone: str) -> str:
        """Standardize South African phone numbers"""
        # Remove all non-numeric characters except +
        phone = ''.join(c for c in phone if c.isdigit() or c == '+')
        
        # Standardize format to +27
        if phone.startswith('0'):
            phone = '+27' + phone[1:]
        elif not phone.startswith('+'):
            phone = '+27' + phone
        
        return phone

    def is_valid_email(self, email: str) -> bool:
        """Validate email format"""
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(email_pattern, email))