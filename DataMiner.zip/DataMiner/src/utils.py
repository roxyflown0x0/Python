# src/utils.py

import logging
import os
import json
from datetime import datetime
from typing import Any, Dict, List
from config.config import OUTPUT_SETTINGS

def setup_logging():
    """Configure logging settings"""
    log_dir = OUTPUT_SETTINGS['log_dir']
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
        
    timestamp = datetime.now().strftime(OUTPUT_SETTINGS['timestamp_format'])
    log_file = os.path.join(log_dir, f'scraper_{timestamp}.log')
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler()
        ]
    )

def save_json(data: Dict[str, Any], filename: str):
    """Save data to JSON file"""
    output_dir = OUTPUT_SETTINGS['output_dir']
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        
    filepath = os.path.join(output_dir, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)
    
    logging.info(f"Data saved to {filepath}")

def clean_text(text: str) -> str:
    """Clean and normalize text"""
    if not text:
        return ""
    
    # Remove extra whitespace
    text = ' '.join(text.split())
    # Remove special characters but keep basic punctuation
    text = ''.join(char for char in text if char.isprintable())
    return text.strip()

def create_output_directories():
    """Create necessary output directories"""
    directories = [
        OUTPUT_SETTINGS['output_dir'],
        OUTPUT_SETTINGS['log_dir']
    ]
    
    for directory in directories:
        if not os.path.exists(directory):
            os.makedirs(directory)
            logging.info(f"Created directory: {directory}")

def format_filename(base_name: str, extension: str) -> str:
    """Format filename with timestamp"""
    timestamp = datetime.now().strftime(OUTPUT_SETTINGS['timestamp_format'])
    return f"{base_name}_{timestamp}.{extension}"

def load_custom_dorks(filename: str) -> List[str]:
    """Load custom Google dorks from file"""
    try:
        if not os.path.exists(filename):
            logging.warning(f"Custom dorks file not found: {filename}")
            # Create the file with some example dorks
            example_dorks = [
                "# Add your custom Google dorks here (one per line)",
                "# Lines starting with # are ignored",
                "",
                "site:linkedin.com/in/ \"manufacturing\" \"CEO\" \"South Africa\"",
                "site:za.linkedin.com \"manufacturing\" \"CEO\" \"email\"",
                "intext:\"@\" intext:\"phone\" site:za (CEO OR Director) \"manufacturing\""
            ]
            with open(filename, 'w', encoding='utf-8') as f:
                f.write('\n'.join(example_dorks))
            logging.info(f"Created example dorks file: {filename}")
            return []

        with open(filename, 'r', encoding='utf-8') as f:
            # Read lines and remove empty lines and comments
            dorks = [
                line.strip() for line in f.readlines()
                if line.strip() and not line.strip().startswith('#')
            ]
        
        if not dorks:
            logging.warning("No dorks found in the file. Please add your dorks to the file.")
            return []
            
        logging.info(f"Loaded {len(dorks)} custom dorks from {filename}")
        return dorks
        
    except Exception as e:
        logging.error(f"Error loading custom dorks: {str(e)}")
        return []

def validate_config():
    """Validate configuration settings"""
    required_dirs = [
        OUTPUT_SETTINGS['output_dir'],
        OUTPUT_SETTINGS['log_dir']
    ]
    
    for directory in required_dirs:
        if not os.path.exists(directory):
            try:
                os.makedirs(directory)
                logging.info(f"Created directory: {directory}")
            except Exception as e:
                logging.error(f"Error creating directory {directory}: {str(e)}")
                return False
    
    return True

def sanitize_filename(filename: str) -> str:
    """Sanitize filename to remove invalid characters"""
    # Remove invalid characters
    invalid_chars = '<>:"/\\|?*'
    for char in invalid_chars:
        filename = filename.replace(char, '')
    
    # Limit length
    max_length = 255
    if len(filename) > max_length:
        name, ext = os.path.splitext(filename)
        filename = name[:max_length-len(ext)] + ext
    
    return filename

def get_timestamp() -> str:
    """Get formatted timestamp"""
    return datetime.now().strftime(OUTPUT_SETTINGS['timestamp_format'])

def ensure_directory_exists(directory: str):
    """Ensure directory exists, create if it doesn't"""
    if not os.path.exists(directory):
        os.makedirs(directory)
        logging.info(f"Created directory: {directory}")