# config/config.py

import os

# Google API Credentials
API_KEYS = [
    "AIzaSyDbEXo40_A2tLsQaWQmSvaF6SpJrqW34K0",
    "AIzaSyDlToEKJqB2speXspWoYHP-fFsrMrby3gE",
    "AIzaSyDSSfXv7fTCiB_xjCPdI9v43KCqF9LztZ8",
    "AIzaSyAyKJyMXOVzsYAl-d8Nqjappzt_KBHdVm0",
    "AIzaSyDNVzGNZ4cT7eWwjQD6NmppTZ-AuqzzTk0",
    "AIzaSyDTuJCMcTYgFKMcjB71zQuFY7Q0ZbuP218",
    "AIzaSyC4FDovZCwUI0BqAyPIGhiHMXnA9qQl7lg",
    "AIzaSyCbUxyyg8J_DUoKeYgCuAE3CwD9TKLFVWQ",
    "AIzaSyDNVzGNZ4cT7eWwjQD6NmppTZ-AuqzzTk0",
    "AIzaSyDTuJCMcTYgFKMcjB71zQuFY7Q0ZbuP218",
    "AIzaSyBruaD3zSc-g0jF-6b_Qu08KU3cjoKwivg",
    "AIzaSyBBKYswGbKlLtJtRWDx428JtIU4KxT4ui0",
    "AIzaSyDB3xuXOdjAIrtyolAyJt8LfxU4KxT4ui0",
    "AIzaSyDi3BWSNNFu5hZnF5Wtq8GxUMnYu2Zk5gg",
    "AIzaSyAJP5AVdYOgvMuYoT2XEM0MjPrAYxnB8ns"
]

CSE_IDS = [
    "02671555df2224350", "45f738cd2cb484722", "248848c670d0f4f8c",
    "3457c8f927de246f4", "70781f2a9a68c49ac", "d1df5a600b5b94ec3",
    "f40e16c48afe34e3c", "a6072bc1dcf8c4d79", "60c9873c261204718",
    "e26ede76286a544e8", "d4e2ebf258b944f91", "c481c3a651fe142c9",
    "14fe45fe39ab2419a", "654800b8f8639452b", "74e2699945a994c1d",
    "051f685c02e0d44ae", "133d48265e2e44adc", "64a279f8504804cbb",
    "b35926315544d4e47", "212b86f2ce1f74dd1", "76c72f14d9dfe42ab"
]

# Regex Patterns for Information Extraction
PATTERNS = {
    'phone': r'(?:\+27|0)(?:\d[\s-]*){9}',
    'email': r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
    'position': r'(?i)(CEO|Chief Executive|Director|Chairman|Managing Director|Executive)',
    'name': r'[A-Z][a-z]+ (?:[A-Z][a-z]+ )*[A-Z][a-z]+',
    'company': r'(?i)([A-Z][A-Za-z0-9\s&]+(?:Ltd|Limited|Pty|Corporation|Inc|Group|Holdings))',
    'address': r'(?i)([A-Za-z0-9\s,.-]+(?:Street|Road|Avenue|Drive|Lane|Boulevard|Park|Building)[A-Za-z0-9\s,.-]+(?:South Africa))'
}

# Preview Settings
PREVIEW_SETTINGS = {
    'max_preview_length': 200,
    'refresh_rate': 2,
    'show_stats': True,
    'terminal_width': 100,
    'max_results_shown': 5
}

# Scraper Settings
SCRAPER_SETTINGS = {
    'delay_min': 1,
    'delay_max': 3,
    'max_retries': 3,
    'timeout': 30,
    'batch_size': 10,
    'max_results_per_query': 100,
    'verify_ssl': True,
    'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'max_workers': 5,
    'custom_dorks_file': 'custom_dorks.txt'  # New setting for custom dorks file
}

# Output Settings
OUTPUT_SETTINGS = {
    'output_dir': 'output',
    'log_dir': 'logs',
    'csv_filename': 'manufacturing_contacts',
    'json_filename': 'manufacturing_contacts',
    'excel_filename': 'manufacturing_contacts',
    'timestamp_format': '%Y%m%d_%H%M%S'
}

# Rate Limiting Settings
RATE_LIMIT = {
    'max_requests_per_day': 100,
    'max_requests_per_minute': 5,
    'quota_reset_hour': 0
}